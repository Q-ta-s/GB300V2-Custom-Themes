-This theme is for GB300 V2 firmware.
(In the case of affect of applying this to GB300 V1 or other firmware has 
not been confirme)

- This file contains only the difference of theme changes.
Overwrite the official resource file with the this difference files,
apply the theme.

After applying the theme, be sure to run below batch file once the 
first time. (*given "ALL")

/Resources/Qs_tool/Qs_frogtool_gamelistup_v13.bat

*The usage (arguments to be given) is the same as frogtool.
*"SEGA" and "PS1" and "MEDIA" folders will be created under the SD card.

- This theme is different from others in that it is set to refer to the 
"SEGA" and "PS1" and "MEDIA"  folders.

Other tools, including tadpole and frogtool, do not support these folders.
(* As of Feb 2025)
In addition, the order of the game system categories has been customized, 
so to update the list after adding a game (rebuild the game list), 
do not use other tools including tadpole and frogtool, but use the 
"Qs_tool" batch file instead.

/Resources/Qs_tool/Qs_frogtool_gamelistup_v13.bat

*The usage (arguments to be given) is the same as frogtool.

"SEGA"  folder: Place SEGA games. (Sega CD/GG/SMS)
"PS1" folder: Place PlayStation game (zfb) files.
"GBA" folder: Place GBA/GB/COLOR games.
"MEDIA" folder: Place Music/Video files (zfb files).
*Other above, it is OK to put the game to same category name folder.

Then run "Qs_frogtool_gamelistup_v13.bat" to rebuild the game list.

- In case want to change the category of the game system,
that have prepared resource files for different patterns.
Please replace the resources as appropriate.
(For other patterns, please refer to the "#Screenshot" folder)

- Four shortcuts is delete from the main menu on each system.
(Due to layout. )
If push A on mainmenu show "loading" screen, but as soon hide.

- Other points to note:
xfgle.hgp and Sound files (nyquest.gdb, swapfile.sys, mfsvr.nkf, 
oldversion.kbe etc) will be overwritten too. Apply after back up the existing 
resource file, recommend.

*If an error occurs during list reconstruction processing using a 
batch file, please contact @Q_ta with Discord.

----------------------------------------------------------------------
*The above batch file (Qs_frogtool_gamelistup_v13.bat) automates the 
troublesome movement of game below.
if rebuild gamelist with frogtool (v0.2.8 later) etc, place the game 
in the below folder.
*frogtool v0.2.8 (for GB300v2) download: 
https://github.com/Q-ta-s/q-ta-s.github.io/raw/refs/heads/main/bin/tools/gb300v2/frogtool-gb300v2-win.zip

"GB"  folder: Place SEGA games. (Sega CD/GG/SMS)
"GBC" folder: Place PlayStation game (zfb) files.
"GBA" folder: Place GBA/GB/COLOR games.
"PCE" folder: Place Music/Video files (zfb files).
*Other above, it is OK to put the game to same category name folder.

After rebuilding the list, place the game in the folder below.
"SEGA"  folder: Place SEGA games. (Sega CD/GG/SMS)
"PS1" folder: Place PlayStation game (zfb) files.
"GBA" folder: Place GBA/GB/COLOR games.
"MEDIA" folder: Place Music/Video files (zfb files).
*Other above, it is OK to put the game to same category name folder.
