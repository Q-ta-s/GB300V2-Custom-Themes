-This theme is for GB300 V2 firmware.
(In the case of affect of applying this to GB300 V1 or other firmware has 
not been confirme)

- This file contains only the difference of theme changes.
Overwrite the official resource file with the this difference files,
apply the theme.
*Apply after back up the existing resource file, recommend.

- Four shortcuts was delete from the main menu on each system.
(Due to layout. )
By default, the cursor for shortcuts was in "stardust cursor" mode, 
which makes it hard to see the cursor movement in "User ROMS & Settings". 
To switch to "regular cursor" mode, run below batch file.

/Resources/Qs_tool/Qs_switch_cursor.bat

*If run batch file again, cursor will revert to stardust cursor mode.

- Other points to note:
Sound files (nyquest.gdb, swapfile.sys, mfsvr.nkf, oldversion.kbe etc) 
will be overwritten too. Apply after back up the existing resource file, 
recommend.

*If an error occurs during list reconstruction processing using a 
batch file, please contact @Q_ta with Discord.
